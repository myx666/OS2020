# lab1实验报告

## 练习1
### 1.操作系统镜像文件ucore.img是如何一步一步生成的？(需要比较详细地解释Makefile中每一条相关命令和命令参数的含义，以及说明命令导致的结果)
- gcc -Ikern/init/ -fno-builtin -Wall -ggdb -m32 -gstabs -nostdinc  -fno-stack-protector -Ilibs/ -Ikern/debug/ -Ikern/driver/ -Ikern/trap/ -Ikern/mm/ -c kern/init/init.c -o obj/kern/init/init.o 等命令通过gcc编译.c文件得到.o文件，其中：
  - -fno-builtin：避免与Ｃ语言运行库里面已经存在的函数名冲突。
  - -Wall：编译后显示所有警告。
  - -ggdb：产生GDB使用的debug信息。
  - -m32：生成32位机器的汇编代码。
  - -gstabs：以stab格式生成GDB调试信息。
  - -nostdinc：编译器将不在系统头文件路径下搜索。
  - -fno-stack-protector：禁用栈保护措施。

- ld -m    elf_i386 -nostdlib -N -e start -Ttext 0x7C00 obj/boot/bootasm.o obj/boot/bootmain.o -o obj/bootblock.o
'obj/bootblock.out' size: 488 bytes 等命令将目标文件转换为执行程序，其中：
  - -nostdlib：不链接C标准库。
  - -N：将代码区和数据区设置为可读可写，不对数据区进行页对齐，不链接标准库。
  - -e start:设置入口函数为`start`。
  - -Ttext 0x7C00:设定主引导扇区被读取到内存的地址。
  
- dd if=/dev/zero of=bin/ucore.img count=10000 等命令把bootloader放到虚拟硬盘当中，生成.img文件，其中：
  - if：输入文件。
  - of：输出文件。
  - count：拷贝block的个数。
  - seek：数据拷贝起始block寻址。
  - conv=notrunc：不截短输出文件。
  
### 2.一个被系统认为是符合规范的硬盘主引导扇区的特征是什么？
根据tools/sign.c，主扇区大小为512字节，其中最后两位应为0x55、0xAA。

## 练习2
### 1.从CPU加电后执行的第一条指令开始，单步跟踪BIOS的执行。
在Makefile中加入：
```
lab1-mon: $(UCOREIMG)
	$(V)$(TERMINAL) -e "$(QEMU) -S -s -d in_asm -D $(BINDIR)/q.log -monitor stdio -hda $< -serial null"
	$(V)sleep 2
	$(V)$(TERMINAL) -e "gdb -tui -q -x tools/lab1init"
```
并在tool文件夹下加入lab1init，内容如下：
```
file bin/kernel
target remote :1234
set architecture i8086
```
其中：

file bin/kernel表示执行ucore的命令；

target remote :1234表示与qemu连接；

set architecture i8086表示初始设置为8086实模式。

再在gdb中输入相应指令，即可跟踪当前执行指令（即$pc）。

### 2.在初始化位置0x7c00设置实地址断点,测试断点正常。
在lab1init中继续加入
```
break *0x7C00
continue
```
其中：

break \*0x7c00表示在0x7c00设置断点；

continue表示继续执行。


### 3.从0x7c00开始跟踪代码运行,将单步跟踪反汇编得到的代码与bootasm.S和 bootblock.asm进行比较。
在lab1init中加入  
```
x /2i $pc
```
即可查看断点后的两条指令。更改数量至10，可以与bootasm.S和 bootblock.asm进行比较，发现二者几乎相同。

### 4.自己找一个bootloader或内核中的代码位置，设置断点并进行测试。
在pmm_init()处加入断点进行测试，得到GDB输出10条指令结果如下：
```
0x1026c6 <pmm_init>: push   %bp
   0x1026c7 <pmm_init+1>:       mov    %sp,%bp
   0x1026c9 <pmm_init+3>:       call   0x1025c4 <lgdt+51>
   0x1026cc <pmm_init+6>:       (bad)  
   0x1026cd <pmm_init+7>:       lcall  *-0x3d(%di)
   0x1026d0 <printnum>: push   %bp
   0x1026d1 <printnum+1>:       mov    %sp,%bp
   0x1026d3 <printnum+3>:       sub    $0x58,%sp
   0x1026d6 <printnum+6>:       mov    0x10(%di),%ax
   0x1026d9 <printnum+9>:       mov    %ax,-0x30(%di)
```

## 练习3
### BIOS将通过读取硬盘主引导扇区到内存，并转跳到对应内存中的位置执行bootloader。请分析bootloader是如何完成从实模式进入保护模式的。
从BIOS到Bootloader时，CPU处于16位的实模式，且CS：IP寻址最多20位。但是80286的地址可以访问更多，为了实现向下兼容，设计了A20Gate，使得第21根线恒为0（回卷操作）。这样进入保护模式也只能访问奇数兆的地址，所以需要使能A20Gate，然后初始化GDT表，最后使能CR0寄存器PE位，跳转到32位地址，完成实模式到保护模式的转换。具体过程根据bootasm.S的代码分析如下：
- 16-23行：禁止中断，设置ES、DS、SS段寄存器为0（初始化）；
- 25-42行：使能A20。等待8042 Input buffer为空；发送Write 8042 Output Port（P2）命令到8042 Input buffer；等待8042 Input buffer为空；将8042 Output Port（P2）得到字节的第2位置1，然后写入8042 Input buffer；
- 49行：读取GDT。GDT是设置好的，读取一个段描述符做为段表的首位；
- 50-56行：使能CR0寄存器的PE位，跳转到32位地址，完成从保护模式到保护模式的转换；
- 58行以后：进入保护模式。

## 练习4
### 通过阅读bootmain.c，了解bootloader如何加载ELF文件。通过分析源代码和通过qemu来运行并调试bootloader&OS，
### bootloader如何读取硬盘扇区的？
根据bootmain.c的33-61行，bootloader在定义了基本的等待函数和访问函数后，开始对硬盘扇区进行访问，流程如下：
- while循环访问0x1f7端口，查询是否忙，直到不忙则返回；
- 向0x1f2端口写入读扇区的个数；
- 向0x1f3-0x1f6写入读扇区号的不同位；
- 向0x1f7写入0x20命令（读扇区）；
- while循环等待0x1f7端口，直到不忙；
- 调用insl读取第一个扇区的内容到指定地址。

### bootloader是如何加载ELF格式的OS？
根据bootmain.c的63-115行，在实现了读取多块地址的基本函数后，具体加载过程如下：
- 读取ELF头部的8个扇区临时存储；
- 判断ELFHDR->e_magic是否等于ELF_MAGIC，即文件类型的判定。如果类型错误跳转到bad分支，输出提示信息后什么都不做；
- 从ELF头部读取ph表的地址和ph数量；
- 遍历所有的ph，以扇区为单位复制其中存储的内容到虚拟内存中；
- 跳转到ELF头部定义的入口地址开始执行ucore。

## 练习5
### 请完成实验，看看输出是否与上述显示大致一致，并解释最后一行各个数值的含义。
函数实现代码以及注释如下：
```
void
print_stackframe(void) {
	uint32_t ebp = read_ebp();	//获取当前ebp
	uint32_t eip = read_eip();	//获取当前eip
	int i,j;
	for(i = 0; i < STACKFRAME_DEPTH && ebp != 0; i ++)  //直到栈底，循环输出
	{
		cprintf("ebp:0x%08x eip:0x%08x args:", ebp, eip);  //打印ebp,eip的值
		for(j = 0; j < 4; j ++)		            //打印参数值
		{
			cprintf("0x%08x ", *((uint32_t*) ebp + 2 + j));
		}
		cprintf("\n");
		print_debuginfo(eip - 1);		    //打印对应函数信息
		eip = *((uint32_t*) ebp + 1);	            //更新eip
		ebp = *((uint32_t*) ebp);		    //更新ebp
	}
}
```
编译运行后，程序输出如下：
```
ebp:0x00007b08 eip:0x001009a6 args:0x00010094 0x00000000 0x00007b38 0x00100092 
    kern/debug/kdebug.c:306: print_stackframe+21
ebp:0x00007b18 eip:0x00100c8f args:0x00000000 0x00000000 0x00000000 0x00007b88 
    kern/debug/kmonitor.c:125: mon_backtrace+10
ebp:0x00007b38 eip:0x00100092 args:0x00000000 0x00007b60 0xffff0000 0x00007b64 
    kern/init/init.c:48: grade_backtrace2+33
ebp:0x00007b58 eip:0x001000bb args:0x00000000 0xffff0000 0x00007b84 0x00000029 
    kern/init/init.c:53: grade_backtrace1+38
ebp:0x00007b78 eip:0x001000d9 args:0x00000000 0x00100000 0xffff0000 0x0000001d 
    kern/init/init.c:58: grade_backtrace0+23
ebp:0x00007b98 eip:0x001000fe args:0x001032dc 0x001032c0 0x0000130a 0x00000000 
    kern/init/init.c:63: grade_backtrace+34
ebp:0x00007bc8 eip:0x00100055 args:0x00000000 0x00000000 0x00000000 0x00010094 
    kern/init/init.c:28: kern_init+84
ebp:0x00007bf8 eip:0x00007d68 args:0xc031fcfa 0xc08ed88e 0x64e4d08e 0xfa7502a8 
    <unknow>: -- 0x00007d67 --
```
经比较，与示例基本一致。最后两行的含义为：
- ebp：栈帧基址的值；
- eip：即将执行的指令地址；
- args：执行函数时压栈的参数；
- 第二行：调用print_debuginfo()函数得到的函数信息，包括执行函数存放位置、函数名和行数。

## 练习6
### 1.中断描述符表（也可简称为保护模式下的中断向量表）中一个表项占多少字节？其中哪几位代表中断处理代码的入口？
一个表项8字节，0-32位代表了处理代码的入口。其中0-15位代表地址偏移，16-31位代表段号。

### 2.请编程完善kern/trap/trap.c中对中断向量表进行初始化的函数idt_init。在idt_init函数中，依次对所有中断入口进行初始化。使用mmu.h中的SETGATE宏，填充idt数组内容。每个中断的入口由tools/vectors.c生成，使用trap.c中声明的vectors数组即可。
idt_init()函数实现代码以及注释如下：
```
extern uintptr_t __vectors[];	//extern表示外部调用，__vectors[]是向量数组
	int i;
	for(i = 0; i < 256; i ++)	//遍历idt的所有项
	{
		if(i == T_SWITCH_TOK)  //如果有特权转换
		{
			SETGATE(idt[i], 1, KERNEL_CS, __vectors[i], DPL_USER);
		}
		else	//否则依旧在KERNEL态执行
		{
			SETGATE(idt[i], 0, KERNEL_CS, __vectors[i], DPL_KERNEL);
		}
	}
	lidt(&idt_pd);	//加载idt
```

### 3.请编程完善trap.c中的中断处理函数trap，在对时钟中断进行处理的部分填写trap函数中处理时钟中断的部分，使操作系统每遇到100次时钟中断后，调用print_ticks子程序，向屏幕上打印一行文字”100 ticks”。
trap_dispatch()函数部分实现代码以及注释如下：
```
ticks ++;
if(ticks % TICK_NUM == 0)	//每100次时钟跳变打印一次信息
{
	print_ticks();
}
```
最后编译运行程序，得到输出如下：
```
...
100 ticks
100 ticks
100 ticks
...
```
符合题目要求。

## 我的实现与参考答案的区别
- 练习2跟踪的函数指令不同，我选择了pmm_init()并且跟踪了10条；
- 练习6对于状态判断的过程不同，答案是先全部视为内核态，再根据T_SWITCH_TOK设置用户态；此外对于SETGATE的第二个参数我认为是KERNEL_CS。

## 本实验中重要的知识点，以及与对应的OS原理中的知识点
- 练习1：文件生成过程；扇区读取规范；
- 练习2：BIOS的执行；debug的指令跟踪方法；
- 练习3：BIOS到bootloader的转换；实模式到保护模式的转换；
- 练习4：bootloader到ucore的转换；
- 练习5：函数调用栈的结构；
- 练习6：中断描述符表的建立；

## 我认为OS原理中很重要，但在实验中没有对应上的知识点 
- 实模式下的段机制访问。















