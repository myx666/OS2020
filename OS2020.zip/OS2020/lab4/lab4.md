# Lab4实验报告

## 练习1

### 实现过程

初始化如下：

- state: 进程状态；pid: -1；parent: 父进程；
- mm: 虚拟内存管理器；
- cr3: 页表起始地址；

### 请说明 proc_struct 中struct context context和struct trapframe *tf成员变量含义和在本实验中的作用是啥？

- `context`的作用是进程切换，存储了当前的CPU上下文（内核态）；
- `trapframe`存储了当前用户态上下文，用与转换。设置系统调用返回值或返回地址时也可以用到。

## 练习2

### 实现过程

- 指定PCB父进程，分配内核栈空间
- 拷贝mm_struct，建立新进程的地址映射关系
- 拷贝父进程的栈帧并且设置子进程返回值为0
- 唤醒进程，设置父进程返回子进程的pid

### 请说明 ucore 是否做到给每个新 fork 的线程一个唯一的 id？请说明你的分析和理由。

是唯一的。分配pid时不会分配已经有过的pid。

## 练习3

### 请在实验报告中简要说明你对 proc_run 函数的分析。并回答如下问题：

- 在本实验的执行过程中，创建且运行了几个内核线程？
- 语句local_intr_save(intr_flag);....local_intr_restore(intr_flag);在这里有何作用?请说明理由

proc_run将当前运行进程切换到proc，调用switch_to函数读取上下文到cpu。lcr3切换页表为proc对应的。至此进程切换完毕。

两个线程：idle和init。

作用：屏蔽中断，保证进程切换的时候不会被中断。也就是说整个进程切换是一个原子操作。

